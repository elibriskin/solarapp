import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

import censusgeocode as cg
from nrel_dev_api import set_nrel_api_key
from nrel_dev_api.solar import SolarResourceData, PVWattsV6
from census import Census
from us import states

census_key = "643fe7b4cd4581823fb346ee10ece4257c656e88"
set_nrel_api_key("HSgd1b4hnY5JLV0uq3eXXZdiAZKt0GaEShXEYzsQ")

c = Census(census_key)

# fips = pd.read_table("fips2county.tsv")
# fips["Address"] = fips["CountyName"].str.cat(fips["StateAbbr"], sep = ", ")

# options = fips.Address.unique()

# address = str(fips[fips["CountyFIPS"]==1001].Address.values[0])



# countydata = pd.DataFrame(c.acs5.get('NAME', {'for': 'county:*'}))
# countydata.to_csv("countydata.csv")

# energy = pd.DataFrame(c.acs5.get([
#     'B25040_001E',
#     'B25040_002E',
#     'B25040_003E',
#     'B25040_004E' ,
#     'B25040_005E',
#     'B25040_006E',
#     'B25040_007E',
#     'B25040_008E',
#     'B25040_009E'
# ], {'for': 'county:*'}))
#
# dict = {
#     'B25040_001E': 'Total',
#     'B25040_002E': 'Utility_Gas',
#     'B25040_003E': 'BottledTankLPGas',
#     'B25040_004E': 'Electricity',
#     'B25040_005E': 'Fuel',
#     'B25040_006E': 'Coal',
#     'B25040_007E': 'Wood',
#     'B25040_008E': 'Solar',
#     'B25040_009E': 'Other'
# }
# energy.rename(columns=dict, inplace=True)
# energy.to_csv("energy.csv")

energy = pd.read_csv("energy.csv")
countydata = pd.read_csv("countydata.csv")
energycounty = pd.read_csv("energycounty.csv")
kw = 293.07107
energycounty['consumption_kw'] = energycounty['Consumption MMBtu'] * kw

energycounty2021 = energycounty[energycounty.Year == 2021]

countydata.NAME = countydata.NAME.str.replace(" County", "")

options = countydata.NAME.unique()

choice = options[0]

solar_resource_data = SolarResourceData(address=choice).outputs

pv_data = PVWattsV6(system_capacity=50, module_type=0, losses=.3, array_type=0, tilt = 30, azimuth=0, address=choice)

county_choice = countydata[countydata.NAME == choice].county[0]
state_choice = countydata[countydata.NAME == choice].state[0]

energy_county = energy[(energy.county==county_choice) & (energy.state == state_choice)]
energycounty2021_county = energycounty2021[energycounty2021['County Name'] == choice]

# [print(f'{energy}: {energy_county[energy]}') for energy in energy_county.columns[1:8]]
# result = cg.address(county='Baldwin')

#Dashboard Data

ac_kw = pv_data.outputs['ac_annual']
consumption = energycounty2021_county.consumption_kw
solar_pct = ac_kw / consumption


ghi = solar_resource_data['avg_ghi']['annual']
dni = solar_resource_data['avg_dni']['annual']


